+peliculas=[]
def borrarPantala():
    import os
    os.sistem("cls")
peliculas = ()   
def esperarTecla():
    input("\n\t\t\t Oprima cualquier tecla para continuar")
def agregarPeliculas():
    borrarPantala()
    print("\n\t\t\t  .:: Agrega Peliculas::.")
    pelicula.append(input("Ingresa el nombre: ").upper().stript())
    input("\n\t\t\t:::LA OPERACION SE REALIZO CON EXITO")
    
def consultarPeliculas():
    borrarPantala()
    
    print(f"{i+1} : {peliculas}")
    if len(peliculas)>0:
        for i in range (0, len(peliculas)):
            print(f"{i+1}" : {peliculas}{i})
            
def vaciarPeliculas():
    borrarPantala()
    print("\n\t\t\t.:: Limopiar o Borrar TODAS las peliculas")
    resp=input("¿Deseas Borrr TODAS las peliculas? (SI/NO)").lower
    if resp =="si":
        peliculas.clear()
        print("\n\t\t\tLA OPERACION SE REALIZO CON EXITO"EWQ)
                